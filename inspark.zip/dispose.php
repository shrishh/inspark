<!DOCTYPE html>
<html>
    <head> 
        <title>Disposing</title>
        <link rel="stylesheet" href="style4.css">
    </head>
    <body>
        <div class = "content">
            <form class="dispose-form" method="post" action="includes/dispose.inc.php">
                <input type="text" name="vname" placeholder="Vehicle Name" required=""/>
                <input type="text" name="vno" placeholder="Vehicle Number" required=""/>
                <input type="text" name="modelno" placeholder="Model Year" required=""/>
                <input type="text" name="ownername" placeholder="Owner's name" required=""/>
                <input type="text" name="phno" placeholder="Phone Number" required=""/>
            </form>
        </div>
    </body>
</html>

































<?php
    require 'footer.php';
?>