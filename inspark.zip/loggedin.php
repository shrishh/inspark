
    <?php 
     require 'header.php';
    ?>

    <!-----------Slider------------>
    <div id="Slider">
    <div id="headerSlider" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#headerSlider" data-slide-to="0" class="active"></li>
    <li data-target="#headerSlider" data-slide-to="1"></li>
    <li data-target="#headerSlider" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/banner1.jpg" class="d-block img-fluid">
        <div class="carousel-caption">
        <h5>Sell your car for the best price!</h5>
        </div>
    </div>
    <div class="carousel-item">
      <img src="img/banner2.jpg" class="d-block img-fluid">
        <div class="carousel-caption">
        <h5>Get rid of your unwanted Vehicle</h5>
        </div>
    </div>
    <div class="carousel-item">
      <img src="img/banner3.jpg" class="d-block img-fluid">
        <div class="carousel-caption">
        <h5>Car-pulling</h5>
        </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#headerSlider" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#headerSlider" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
    </div>
    <!-----------About----------->
    <section id="about">
        <div class="container">
        <div class="row">
        <div class="col-md-6">
            <h3>About Us</h3>
                <div class="about-content">
                This is a site where you can dispose off your unwanted automobiles or get your cars towed. You could also sell or buy cars here ^.^
                </div>
            <button type="button" class="btn btn-primary">Read more>> 
            </button>
            </div>
            <div class="col-md-6">
                Click the button below to Log out<br>
                <a href="index.php" class="btn btn-primary"> Bye-Bye</a>
            </div>
            
            </div>
        </div>
    </section>
<!------------------Buy/Sell-------------------->
<section id="buysell">
    <div class="container">
        <h1>Buy and Sell</h1>
        <div class = "row services">
            <div class="col-md-6 text-center">
                <div class="icon">
                    <i class="fa fa-desktop"></i>
                </div>
                <a href="buysell.php"><h3>Buy</h3></a>
                <p>Treat yourself and buy a car for lowest prices from our site, Carify.com .We ensure legitimate sellers and dealers.</p>
                </div>
           <div class="col-md-6 text-center">
                 <div class="icon">
                    <i class="fa fa-tablet"></i>
                      </div>
                <a href="buysell.php"> <h3>Sell</h3></a>
                <p>You can sell your car for a good price at our site, Carify.com. We will ensure the best transactions and proper paper-work</p>
            
               </div>
        </div>
    </div>

</section>
<!--------------------Dispose-------------------->


<section id="dispose">
<div class="container">
    <h1>Get rid of your car!</h1>
    <div class = "row"></div>
    <div class="col-md text-center">
            Click the button below to Dispose your Cars!<br>
                <a href="dispose.php" class="btn btn-primary"> Dispose</a>
        </div>
    </div>   
</section>

<?php 
     require 'footer.php';
    ?>
</body> 
</html>



