<!DOCTYPE html>
<html>
<head><title>Login and Registration Form Design</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <div class="login-page">
    <div class= "form">
        <form class="register-form"  action="includes/register.inc.php" method="post">
            <input type="text" name="uid" placeholder="Username" required=""/>
            <input type="text" name = "mail" placeholder="Email ID" required=""/>
            <input type="password" name = "pwd" placeholder="Password" required=""/> 
            <input type="password" name = "pwd-repeat" placeholder="Repeat Password" required=""/> 
            <button name="register-button">Register</button>
            <p class="message">Already Registered?<a href="#">  Login</a></p>
        </form>
    
    <form class= "login-form" action="includes/login.inc.php" method="post">
        <input type="text" name="mailuid" placeholder= "Username/E-mail" required=""/>
         <input type="password" name = "pwd" placeholder="Password" required=""/>
        <button name="login-button">Login</button>
        <p class="message">Not Registered?<a href="#">  Register</a></p>
    </form>
    </div>
    </div>

<script src='https://code.jquery.com/jquery-3.3.1.min.js'></script>


<script>
    $('.message a').click(function(){
        $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
    });
</script>
 <?php 
     require 'footer.php';
    ?>
</body>
    
   
</html>