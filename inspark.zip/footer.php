<!----------------Footer-------------->
<section id="footer">
    <div class="container">
        <p>Made With <i class="fa fa-heart-o"></i> by NMITians</p>
    </div>
</section>
<!----------Footer End----------------->
<script src="js/smooth-scroll.js"></script>
<script>
    var scroll = new SmoothScroll('a[href*="#"]');
</script>