<?php
$msg = "";
// if upload button is pressed 
if(isset($_POST["upload"])) {
    // the path to tore the uploaded image 
    $target = "images/".basename($_FILES['image']['name']);
    
    //connect to the database 
    $db = mysqli_connect("localhost", "root", "" , "photos");
    
    //Get all the submitted data from the form
    $image = $_FILES['image']['name'];
    $text = $_POST['text'];
  
    
    $sql = "INSERT INTO images (image, text) VALUES ('$image', '$text')";
    mysqli_query($db, $sql);
    
    if(move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $msg = "Image uploaded successfully";
    }
    else {
        $msg = "There was a problem uploading image";
    }
}


?>


<!DOCTYPE html>
<html>
    <head>
        <title> Buy/Sell </title>
       <link rel="stylesheet" href="style2.css">
    </head>
    <body>
        <div class="content">
            <form method="POST" enctype="multipart/form-data">
                <em><h2>Post your Ad here </h2></em>
                <input type="hidden" name= "size" value= "1000000">
                <div>
                    <input class="textbox" type="file" name="image" required="">
                </div>
                <div>
                    <textarea class="textar" name="text" cols="40" rows="5" placeholder="Say something about this Advertisement..." required="" ></textarea>
                </div>
                <div>
                    <input class="num" type="text" name="number" placeholder="Contact No." required="">
                </div>
                <div>
                    <input class="btn" type="button" name="upload" value="Upload Image">
                </div>
            </form>
        </div>
    </body>
</html>